from django.contrib import admin
from .models import Personal, Product

# Register your models here.

admin.site.register(Product)
admin.site.register(Personal)
