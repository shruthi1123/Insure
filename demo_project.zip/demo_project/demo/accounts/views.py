from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from accounts.models import Personal, Product
from django.contrib.auth import login

# Create your views here.

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return render(request, 'accounts/product_details.htm')
        else:
            messages.info(request, 'invalid credentials')
            return redirect('login')
    
    else:
        return render(request, 'accounts/register.htm')



def register(request):
    
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return redirect('register')

            elif User.objects.filter(email=email).exists():
                messages.info(request, 'email taken')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
                user.save();
                print('user created');
                return redirect('register')
                   
        else:
            print('password not matching')
            return redirect('register')
        return redirect('/')

    else:    
        return render(request,'accounts/register.htm')


def add(request):
    
        return render(request,'accounts/personal.htm')

def create(request):
    if request.method == 'POST':
       price = int(request.POST['product_price'])
       premium = price/10
       product = Product(producttype=request.POST['products'], productname=request.POST['product_name'], productprice=request.POST['product_price'], premium=premium, username=request.POST['user_name'])
       product.save()
       return redirect('item')

def veri(request):
    
    if request.method == 'POST':
        val1 = request.POST['house']
        val2 = request.POST['door']
        if val1 == 'yes':
            if val2 == 'yes':
                return redirect('display')
            else:
                return redirect('edit')
        else:
            return redirect('edit')

def display(request):
    current_user = request.user
    details = Product.objects.filter(username__startswith=current_user.username).values()
    return render(request, 'accounts/display.htm', {'details': details})

def logout(request):
    auth.logout(request)
    return redirect('/')

def item(request):
    return render(request,'accounts/product_details.htm')

def personal(request):
    if request.method == 'POST':
        info = Personal(username=request.POST['user_name'], firstname=request.POST['first_name'], phoneno=request.POST['phone_no'], email=request.POST['email'], address=request.POST['address'] )
        info.save()
        return render(request, 'accounts/check_box.htm')

def edit(request):
    current_user= request.user
    members = Personal.objects.filter(username__startswith=current_user.username).values()
    return render(request, 'accounts/edit.htm', {'members': members})

def date(request):
     return render(request, 'accounts/check_box.htm')
