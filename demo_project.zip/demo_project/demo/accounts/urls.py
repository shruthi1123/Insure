from django.contrib import admin 
from django.urls import path
from .import views
from django.conf.urls import url

urlpatterns = [
    path('register', views.register, name='register'),
    path('login', views.login, name='login'),
    path('logout',views.logout, name='logout' ),
    path('create', views.create, name='create'),
    path('add', views.add, name='add'),
    path('veri', views.veri, name='veri'),
    path('display',views.display, name='display'),
    path('item', views.item, name='item'),
    path('personal', views.personal, name='personal'),
    path('edit', views.edit, name='edit'),
    path('date', views.date, name='date'),
]
