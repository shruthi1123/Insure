from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Product(models.Model):
    username = models.CharField(max_length=50)
    producttype = models.CharField(max_length=40)
    productname = models.CharField(max_length=50)
    productprice = models.IntegerField()
    premium = models.IntegerField()

    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

    class Meta:
        ordering = ['created']

    class Meta:
        db_table = "accounts_product"

class Personal(models.Model):
    username = models.CharField(max_length=50)
    firstname = models.CharField(max_length=50)
    phoneno = models.CharField(max_length=12)
    email = models.CharField(max_length=150)
    address = models.CharField(max_length=150)

    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username
    
    class Meta:
        ordering = ['created']

    class Meta:
        db_table = "accounts_personal"
    
